import unittest

class StillYetAnotherSampleTest(unittest.TestCase):
    
    def setUp(self):
        return

    def tearDown(self):
        return

    def test_non_unique_name(self):
        pass


if __name__ == '__main__':
    unittest.main()
